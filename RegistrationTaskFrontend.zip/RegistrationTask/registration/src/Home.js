import React from "react";
import { useNavigate } from "react-router-dom";

import "./Home.css";

const Home = () => {
  const navigate = useNavigate();
  return (
    <div>
      <form>
        <button
          className="homeButton"
          onClick={() => {
            navigate("/Details");
          }}
        >
          Show details
        </button>
        <button
          className="homeButton"
          onClick={() => {
            navigate("/Form");
          }}
        >
          Register
        </button>
      </form>
    </div>
  );
};

export default Home;
