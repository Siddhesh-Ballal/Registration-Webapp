import React, { useEffect, useState } from "react";
import axios from "axios";
import "./ShowDetails.css";
import moment from "moment";
import { useNavigate } from "react-router-dom";

function ShowDetails() {
  const [info, setInfo] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get("https://localhost:7059/api/User")
      .then((response: AxiosResponse) => {
        setInfo(response.data);
      })
      .catch((err) => {});
  }, []);

  useEffect(() => {
    console.log(info);
  }, [info]);
  return (
    <div>
      <center>
        <table className="styled-table">
          <thead>
            <tr>
              <td>Name</td>
              <td>Mobile number</td>
              <td>Email</td>
              <td>Date of Birth</td>
              <td>Gender</td>
              <td>Address</td>
              <td>Country</td>
              <td>State</td>
              <td>City</td>
              <td>PIN Code</td>
            </tr>
          </thead>
          <tbody>
            {info.map((user) => (
              <tr key={user.id}>
                <td>{user.name}</td>
                <td>{user.mobileNumber}</td>
                <td>{user.email}</td>
                <td>{moment(user.dateOfBirth).format("DD-MM-YYYY")}</td>
                <td>{user.gender}</td>
                <td>{user.address}</td>
                <td>{user.country}</td>
                <td>{user.state}</td>
                <td>{user.city}</td>
                <td>{user.pinCode}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </center>
      <button
        className="homeButton"
        onClick={() => {
          navigate("/");
        }}
      >
        Go back
      </button>
    </div>
  );
}

export default ShowDetails;
