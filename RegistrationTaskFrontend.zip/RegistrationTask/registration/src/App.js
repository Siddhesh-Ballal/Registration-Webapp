import "./App.css";
import React from "react";
import { RegistrationForm } from "./RegistrationForm";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import ShowDetails from "./ShowDetails";
import Home from "./Home";

function App() {
  return (
    <div className="App">
      <h1 className="heading">Registration</h1>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/Form" element={<RegistrationForm />} />
          <Route path="/Details" element={<ShowDetails />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
